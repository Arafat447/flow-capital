

import React from 'react';
import '../header/NavigationMenu.css';
import { Link, Navigate, useNavigate } from "react-router-dom";
import NavigationMenu from './NavigationMenu';


const HeaderNew = () => {

    const navigate = useNavigate();
    const headerClickHandler = e => {
        e.preventDefault()
        // navigate(-1);
        navigate("/")
    };

    return (
        <div className="sticky__top">
            <div className="hd__navbar">
                <NavigationMenu />
            </div>
        </div>
    );
};

export default HeaderNew;

