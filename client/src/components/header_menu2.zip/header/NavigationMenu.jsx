import React, { useState } from 'react';
import '../header/NavigationMenu.css';
import { Link } from 'react-router-dom';
import Logo_resize from '../../assets/Logo_resize.png';
import Australia from '../../assets/Australia.png';
import USA from '../../assets/USA.png';
import Canada from '../../assets/Canada.png';




const NavigationMenu = () => {
    const [isNavExpanded, setIsNavExpanded] = useState(false);
    const menuItems = [
        {
            name: 'HOME',
            link: '/',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'ABOUT',
            link: '#',
            bg_color: '#84154D',
            color: '#fff',
            subMenu: [
                {
                    name: 'ABOUT US',
                    link: 'about',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'MANAGEMENT TEAM',
                    link: 'our-management-team',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'CAREER',
                    link: 'career',
                    bg_color: '#fff',
                    color: '#000',
                },
            ],
        },
        {
            name: 'SERVICES',
            link: '#',
            bg_color: '#FF6600',
            color: '#fff',
            subMenu: [
                {
                    name: 'USA SERVICES',
                    link: 'usa-services',
                    bg_color: '#fff',
                    color: '#000',
                    subMenu: [
                        {
                            id: 1,
                            name: "INDIVIDUAL TAX FEDERAL & STATE",
                            link: "usa-services/1",
                        },
                        {
                            id: 2,
                            name: "PARTNERSHIP TAX FEDERAL & STATE",
                            link: "usa-services/2",
                        },
                        {
                            id: 3,
                            name: "CORPORATE TAX FEDERAL & STATE",
                            link: "usa-services/3",
                        },
                        {
                            id: 4,
                            name: "ESTATE & TRUST FEDERAL & STATE",
                            link: "usa-services/4",
                        },
                        {
                            id: 5,
                            name: "INTERNATIONAL INDIVIDUAL TAX",
                            link: "usa-services/5",
                        },
                        {
                            id: 6,
                            name: "INTERNATIONAL BUSINESS TAX",
                            link: "usa-services/6",
                        },
                        {
                            id: 7,
                            name: "AMENDED & LATE TAX RETURN",
                            link: "usa-services/7",
                        },
                        {
                            id: 8,
                            name: "BOOKKEEPING & PAYROLL",
                            link: "usa-services/8",
                        },
                        {
                            id: 9,
                            name: "REPORTING",
                            link: "usa-services/9",
                        },
                        {
                            id: 10,
                            name: "ENTITY SETUP-USA",
                            link: "usa-services/10",
                        },
                        {
                            id: 11,
                            name: "ENTITY SETUP-FOREIGNER",
                            link: "usa-services/11",
                        },
                        {
                            id: 12,
                            name: "REPRESENTATION",
                            link: "usa-services/12",
                        },
                        {
                            id: 13,
                            name: "ADVISORY",
                            link: "usa-services/13",
                        },
                        // {
                        // subMenu: [
                        //     {
                        //         name: 'and more',
                        //         link: '#',
                        //         subMenu: [
                        //             {
                        //                 name: 'and even more',
                        //                 link: '#',
                        //             },
                        //             // Add more sub-menus if needed
                        //         ],
                        //     },
                        //     {
                        //         name: 'and more',
                        //         link: '#',
                        //     },
                        // ],
                        // },
                    ],
                },
                {
                    name: 'AUSTRALIA SERVICES',
                    link: 'australian-services',
                    bg_color: '#fff',
                    color: '#000',
                    subMenu: [
                        {
                            id: 1,
                            name: "DOMESTIC TAXATION",
                            link: "australian-services/1",
                        },
                        {
                            id: 2,
                            name: "CROSS-BORDER TAXATION",
                            link: "australian-services/2",
                        },
                        {
                            id: 3,
                            name: "FINANCIAL ACCOUNTING",
                            link: "australian-services/3",
                        },
                        {
                            id: 4,
                            name: "LOCAL ENTITY FORMATION",
                            link: "australian-services/4",
                        },
                        {
                            id: 5,
                            name: "INTERNATIONAL EXPANSION",
                            link: "australian-services/5",
                        },
                        {
                            id: 6,
                            name: "AUSTRALIAN MARKET ENTRY",
                            link: "australian-services/6",
                        },
                        {
                            id: 7,
                            name: "AUDITING, PAYROLL TAX AND OTHERS",
                            link: "australian-services/7",
                        },
                        {
                            id: 8,
                            name: "BUSINESS ADVISORY",
                            link: "australian-services/8",
                        },
                    ],
                },
                {
                    name: 'CANADIAN SERVICES',
                    link: 'canadian-services',
                    bg_color: '#fff',
                    color: '#000',
                    subMenu: [
                        {
                            id: 1,
                            name: "LOCAL TAX",
                            link: "canadian-services/1",
                        },
                        {
                            id: 2,
                            name: "CROSS-BORDER TAX",
                            link: "canadian-services/2",
                        },
                        {
                            id: 3,
                            name: "ACCOUNTING & BOOKKEEPING",
                            link: "canadian-services/3",
                        },
                        {
                            id: 4,
                            name: "ENTITY SERVICES",
                            link: "canadian-services/4",
                        },
                        {
                            id: 5,
                            name: "ADVISORY SERVICES",
                            link: "canadian-services/5",
                        },
                    ],
                    },
            ],
        }, {
            name: 'WHY',
            link: '#',
            bg_color: '#84154D',
            color: '#fff',
            subMenu: [
                {
                    name: 'WHY US',
                    link: 'why-us',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'PRIVACY POLICY',
                    link: 'privacy-policy',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'TECH PARTNERS',
                    link: 'tech-partners',
                    bg_color: '#fff',
                    color: '#000',
                },
            ],
        },
        {
            name: 'TESTIMONIAL',
            link: 'testimonial',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'REVIEWS',
            link: 'reviews',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'FAQS',
            link: 'faqs',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'RESOURCES',
            link: 'resources',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'APPOINTMENT',
            link: 'appointment',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'PAYMENT',
            link: 'payment',
            bg_color: '#C40A2A',
            color: '#fff',
        },
    ];

    const renderSubMenu = (subMenu) => {
        if (!subMenu) return null;

        return (
            <ul>
                {subMenu.map((item) => (
                    <li key={item.name}>
                        <Link to={`/${item.link}`} className="nav__link">{item.name}</Link>
                        {renderSubMenu(item.subMenu)}
                    </li>
                ))}
            </ul>
        );
    };

    return (
        <div className="ht__nav">
            <nav className="container container-fluid">
                <div className="row d-flex justify-content-between align-items-center">
                    <div className="col-auto">
                        <Link to="/" className="navbar-brand active" aria-current="page">
                            <img src={Logo_resize} className="img-fluid" style={{ width: '85px', height: 'auto' }} loading='lazy' alt="Logo_resize" border="0" />
                        </Link>
                    </div>
                    <div className="col-auto">
                        <div className="nav__menu">
                            <ul>
                                {menuItems.map((item) => (
                                    <li key={item.name}>
                                        <Link to={item.link} className="nav__link">{item.name}</Link>
                                        {renderSubMenu(item.subMenu)}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className="nav__menu__bar">
                            <button className="menu__btn"
                                onClick={() => { setIsNavExpanded(!isNavExpanded) }}
                            >
                                {isNavExpanded ? <i className="fa-solid fa-xmark"></i> : <i className="fa-solid fa-bars"></i>}
                            </button>
                            <div className={`wrapper ${isNavExpanded == true ? 'active' : ''}`}>
                                <ul>
                                    {menuItems.map((item) => (
                                        <li key={item.name}>
                                            <Link to={item.link}>{item.name}</Link>
                                            {renderSubMenu(item.subMenu)}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="col-auto mx-1">
                        <ul className="list-unstyled">
                            <li className="mb-1">
                                <Link to="#" >
                                    <img src={Australia} alt="image" loading='lazy' />
                                </Link>
                            </li>
                            <li className="mb-1">
                                <Link to="#" >
                                    <img src={USA} alt="image" loading='lazy' />
                                </Link>
                            </li>
                            <li className="">
                                <Link to="#" >
                                    <img src={Canada} alt="image" loading='lazy' />
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    );
};

export default NavigationMenu;
