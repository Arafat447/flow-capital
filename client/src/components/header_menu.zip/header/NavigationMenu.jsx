import React, { useState } from 'react';
import '../header/NavigationMenu.css';
import { Link } from 'react-router-dom';
import Logo_resize from '../../assets/Logo_resize.png';
import Australia from '../../assets/Australia.png';
import USA from '../../assets/USA.png';
import Canada from '../../assets/Canada.png';


const NavigationMenu = () => {
    const [isNavExpanded, setIsNavExpanded] = useState(false);
    const menuItems = [

        {
            name: 'HTML',
            link: '#',
            bg_color: '#FF6600',
            color: '#fff',
            subMenu: [
                {
                    name: 'Introduction to HTML',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                    subMenu: [
                        {
                            name: 'Metadata',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'Text Fundamentals',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'Hyperlinks',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'more',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                            // subMenu: [
                            //     {
                            //         name: 'and more',
                            //         link: '#',
                            //         subMenu: [
                            //             {
                            //                 name: 'and even more',
                            //                 link: '#',
                            //             },
                            //             // Add more sub-menus if needed
                            //         ],
                            //     },
                            //     {
                            //         name: 'and more',
                            //         link: '#',
                            //     },
                            // ],
                        },
                    ],
                },
                {
                    name: 'Multimedia and Embedding',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'HTML Tables',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
            ],
        },
        {
            name: 'HTML',
            link: '#',
            bg_color: '#FF6600',
            color: '#fff',
            subMenu: [
                {
                    name: 'Introduction to HTML',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                    subMenu: [
                        {
                            name: 'Metadata',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'Text Fundamentals',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'Hyperlinks',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                        },
                        {
                            name: 'more',
                            link: '#',
                            bg_color: '#fff',
                            color: '#000',
                            // subMenu: [
                            //     {
                            //         name: 'and more',
                            //         link: '#',
                            //         subMenu: [
                            //             {
                            //                 name: 'and even more',
                            //                 link: '#',
                            //             },
                            //             // Add more sub-menus if needed
                            //         ],
                            //     },
                            //     {
                            //         name: 'and more',
                            //         link: '#',
                            //     },
                            // ],
                        },
                    ],
                },
                {
                    name: 'Multimedia and Embedding',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'HTML Tables',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
            ],
        },
        {
            name: 'CSS',
            link: '#',
            bg_color: '#C40A2A',
            color: '#fff',
        },
        {
            name: 'JavaScript',
            link: '#',
            bg_color: '#84154D',
            color: '#fff',
            subMenu: [
                {
                    name: 'JavaScript Objects',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'Asynchronous JavaScript',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
                {
                    name: 'Client',
                    link: '#',
                    bg_color: '#fff',
                    color: '#000',
                },
            ],
        },
        {
            name: 'About',
            link: '#',
            bg_color: '#098346',
            color: '#fff',
        },
    ];

    const renderSubMenu = (subMenu) => {
        if (!subMenu) return null;

        return (
            <ul>
                {subMenu.map((item) => (
                    <li key={item.name}>
                        <Link to={item.link} className="nav__link">{item.name}</Link>
                        {renderSubMenu(item.subMenu)}
                    </li>
                ))}
            </ul>
        );
    };

    return (
        <div className="ht__nav">
            <nav className="container container-fluid">
                <div className="row d-flex justify-content-between align-items-center">
                    <div className="col-auto">
                        <Link to="/" className="navbar-brand active" aria-current="page">
                            <img src={Logo_resize} className="img-fluid" style={{ width: '85px', height: 'auto' }} loading='lazy' alt="Logo_resize" border="0" />
                        </Link>
                    </div>
                    <div className="col-auto">
                        <div className="nav__menu">
                            <ul>
                                {menuItems.map((item) => (
                                    <li key={item.name}>
                                        <Link to={item.link} className="nav__link">{item.name}</Link>
                                        {renderSubMenu(item.subMenu)}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className="nav__menu__bar">
                            <button className="menu__btn"
                                onClick={() => { setIsNavExpanded(!isNavExpanded) }}
                            >
                                {isNavExpanded ? <i className="fa-solid fa-xmark"></i> : <i className="fa-solid fa-bars"></i>}
                            </button>
                            <div className={`wrapper ${isNavExpanded == true ? 'active' : ''}`}>
                                <ul>
                                    {menuItems.map((item) => (
                                        <li key={item.name}>
                                            <Link to={item.link}>{item.name}</Link>
                                            {renderSubMenu(item.subMenu)}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="col-auto mx-1">
                        <ul className="list-unstyled">
                            <li className="mb-1">
                                <Link to="#" >
                                    <img src={Australia} alt="image" loading='lazy' />
                                </Link>
                            </li>
                            <li className="mb-1">
                                <Link to="#" >
                                    <img src={USA} alt="image" loading='lazy' />
                                </Link>
                            </li>
                            <li className="">
                                <Link to="#" >
                                    <img src={Canada} alt="image" loading='lazy' />
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    );
};

export default NavigationMenu;
